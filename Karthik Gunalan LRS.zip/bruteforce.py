import time
import sys
from collections import deque
def LRS(string):
    l = list(string)
    d = deque(string[1:])
    match = []
    longest_match = []
    while d:
        for i, item in enumerate(d):
            if l[i]==item:
                match.append(item)
            else:
                if len(longest_match) < len(match):
                    longest_match = match
                match = []
        d.popleft()
    return ''.join(longest_match)
 
# Driver program 
X=sys.argv[1]

if X.isalpha():
    start=time.clock()
    print(LRS(X))
    stop=time.clock()
    print(stop-start)
else:
    print("invalid input")   