# -*- coding: utf-8 -*-
"""
Created on Tue Oct 23 19:46:45 2018

@author: Gunalan KC
"""

import time
import sys
class dynamic(object):
    def lrs(self,seq, m, n, dyn):
        if(m == 0 or n == 0):
            return ""
        if(seq[m - 1] == seq[n - 1] and m != n):
            return self.lrs(seq, m - 1, n - 1, dyn) + seq[m - 1]
        else:
            if(dyn[m - 1][n] > dyn[m][n - 1]):
                return self.lrs(seq, m - 1, n,dyn)           
            else:
                return self.lrs(seq, m, n - 1, dyn)
       

    def LRSLength(self,X,T):
        for i in range(1, len(X)):
            for j in range(1, len(X)):
                if(X[i - 1] == X[j - 1] and i != j):
                    T[i][j] = T[i - 1][j - 1] + 1  
                else:
                    T[i][j] = max(T[i - 1][j], T[i][j - 1])
       
X=sys.argv[1]

if X.isalpha():
    w = len(X)
    T = [[0 for x in range(w+1)] for y in range(w+1)] 
    dynamic().LRSLength(X, T)
    start=time.clock()
    print(dynamic().lrs(X, w, w, T))
    stop=time.clock()
    print(stop-start)
else:
    print("invalid input")       

                


